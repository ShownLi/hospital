package com.tourmade.crm.common;

public class Constants {
	
	public final static String USER_KEY="USER_KEY";
	
	public static final String LOGIN_KEY = "loginUser";
	
}
