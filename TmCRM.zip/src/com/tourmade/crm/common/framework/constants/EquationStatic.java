package com.tourmade.crm.common.framework.constants;

public final class EquationStatic {
	
	public static String STANDARD_WEIGHT = "2013091413262125745220";					
	public static String ADIPOSITY = "2013091413590710152652";										
	public static String SHENGAO = "2013091418140653187952";										
	public static String TIZHONG = "201309141814346818243";											
	public static String SHRINK = "2013091418172356882076";											
	public static String UPHOLD = "2013091418175571653606";											
	public static String MODEL_ADIPOSITY = "2013091319382773446755";						
	public static String MODEL_HYPERTENSION = "201309091000152527657";			
	
	public static final String XINDIAN_JH = "2014073015045059751464";
	public static final String HEALTH_JH = "";
}
