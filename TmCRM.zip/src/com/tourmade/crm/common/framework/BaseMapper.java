package com.tourmade.crm.common.framework;

public interface BaseMapper {
	public void defaultFun();
}
