package com.tourmade.crm.common.framework.util;

public class BaseGlobal {
	public static String PAGINATION_PAGE_INDEX="mybatis.page.index";
	public static String PAGINATION_PAGE_SIZE="mybatis.page.size";
}
